// Run this only on an origin you control. A service worker cannot control a different origin.
(async()=>{const sw='/sw.js';if(location.origin!==new URL(sw,location.href).origin)throw new Error('Same-origin service-worker requirement');await navigator.serviceWorker.register(sw,{scope:'/'});console.log('Proxy Lab service worker installed; reload the page to activate it.');})();
