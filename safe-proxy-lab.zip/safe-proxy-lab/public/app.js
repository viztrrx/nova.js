const frame=document.querySelector('#view'), url=document.querySelector('#url');
const nav=[]; let pos=-1;
function go(v){ if(!v) return; const u=v.startsWith('/')?v:'/' + v; frame.src=u; url.value=u; nav.splice(pos+1); nav.push(u); pos++; }
document.querySelector('#go').onclick=()=>go(url.value); document.querySelector('#reload').onclick=()=>frame.contentWindow.location.reload();
document.querySelector('#back').onclick=()=>{if(pos>0){pos--;frame.src=nav[pos];url.value=nav[pos]}};
document.querySelector('#forward').onclick=()=>{if(pos+1<nav.length){pos++;frame.src=nav[pos];url.value=nav[pos]}};
(async()=>{try{await navigator.serviceWorker.register('/sw.js',{scope:'/'});console.log('service worker registered')}catch(e){console.warn(e)}})();
go('/proxy/');
