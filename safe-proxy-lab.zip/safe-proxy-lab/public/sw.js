self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  const u=new URL(event.request.url);
  if(u.origin===self.location.origin && u.pathname.startsWith('/proxy/')){
    const target='/proxy'+u.pathname.slice('/proxy'.length)+(u.search||'');
    event.respondWith(fetch(new Request(target,event.request)));
  }
});
