import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('repo has required browser files',()=>{
  for (const f of ['public/index.html','public/app.js','public/sw.js','public/style.css','server.js']) assert.equal(fs.existsSync(f),true,f);
});
test('service worker contains fetch interception',()=>{
  const s=fs.readFileSync('public/sw.js','utf8');
  assert.match(s,/addEventListener\('fetch'/); assert.match(s,/startsWith\('\/proxy\/'\)/);
});
test('server has explicit local upstream allowlist',()=>{
  const s=fs.readFileSync('server.js','utf8');
  assert.match(s,/127\.0\.0\.1:9090/); assert.match(s,/Upstream not allowed/);
});
